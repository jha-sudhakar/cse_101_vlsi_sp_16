// CSE 101 Winter 2016, PA 1
//
// Name: TODO put both partners' info if applicable
// PID: TODO
// Sources of Help: TODO
// Due: 1/22/2016 at 11:59 PM

#ifndef __WORM_CPP__
#define __WORM_CPP__

#include "Graph.hpp"
#include "Worm.hpp"
#include <list>
// include other libraries as needed

bool canReachBed(int n, int s1, int s2, int d1, int d2, std::list<int> o) {
    // TODO
    return false;
}

#endif
