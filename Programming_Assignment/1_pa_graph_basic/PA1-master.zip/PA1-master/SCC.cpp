// CSE 101 Winter 2016, PA 1
//
// Name: TODO put both partners' info if applicable
// PID: TODO
// Sources of Help: TODO
// Due: 1/22/2016 at 11:59 PM

#ifndef __SCC_CPP__
#define __SCC_CPP__

#include "Graph.hpp"
#include <list>
#include <set>
// include more libraries as needed

template <class T>
std::list<std::set<T> > scc(Graph<T>& g){
    std::list<std::set<T>> SCCS;
    // TODO
    return SCCS;
}

#endif
