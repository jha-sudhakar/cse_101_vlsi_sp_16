// CSE 101 Winter 2016, PA 1
//
// Name: TODO put both partners' info if applicable
// PID: TODO
// Sources of Help: TODO
// Due: 1/22/2016 at 11:59 PM

#ifndef __TOP_ORDER_CPP__
#define __TOP_ORDER_CPP__

#include "Graph.hpp"
#include <list>
// include more libraries as needed

template <class T>
std::list<T> top_order(Graph<T>& g) {
    std::list<T> topOrder;
    // TODO
    return topOrder;
}

#endif
