// DO NOT MODIFY
//
// CSE 101 Winter 2016, PA 1

#ifndef __WORM_HPP__
#define __WORM_HPP__

#include <list>

#define MAX_SIZE 100    // Maximum size of Worm board

bool canReachBed(int n, int s1, int s2, int d1, int d2, std::list<int> o);

#endif
